/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author S
 */
import java.io.*;
import java.net.*;
public class SendEmailDemo {
    public static void main(String[] args){
        try{
            System.out.println("Conecting");
            String host="127.0.0.1";
            int port=25;
            Socket socket = new Socket(host,port);
            System.out.println("Conected");
            BufferedWriter wr= new  BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),"UTF8") );
            BufferedReader rd= new BufferedReader(new InputStreamReader(socket.getInputStream()) );
            String line;
            System.out.println("Kirim Helo\r\n");
            wr.write("Helo jarkom\r\n");
            wr.flush();
            System.out.println("Respon");
            line=rd.readLine();
            System.out.println(line);
            System.out.println("Kirim RCPT TO and MAIL FROM");
            wr.write("MAIL FROM: <user2@sari.com>\r\n");
            wr.write("RCPT TO: <user1@sari.com>\r\n");
            wr.flush();
            System.out.println("Respon:");
            line=rd.readLine();
            System.out.println(line);
            System.out.println("Kirim Data");
            wr.write("Data\r\n");
            wr.flush();
            System.out.println("Respon:");
            line=rd.readLine();
            System.out.println(line);
            System.out.println("Kirim Isi Email");
            wr.write("From: User 1 <user2@sari.com>\r\n");
            wr.write("To: User 2 <user1@sari.com>\r\n");
            wr.write("\r\n");
            wr.write("Ini isi email uji coba");
            wr.write(".\r\n");
            wr.flush();
            System.out.println("Respon:");
            line=rd.readLine();
            System.out.println(line);
            System.out.println("Kirim quit");
            wr.write("QUIT\r\n");
            wr.flush();
            System.out.println("Respon");
            line=rd.readLine();
            System.out.println(line);
            wr.close();
            rd.close();
            socket.close();
            System.out.println("Disconected");
        }
        catch(UnknownHostException e){
            System.err.println(e.getMessage());
            System.exit(1);
        }
        catch(IOException e){
            System.err.println(e.getMessage());
            System.exit(1);
        
        }
    }
}
